package multichat;

public interface maxNum {
	int MAX=10;
}
